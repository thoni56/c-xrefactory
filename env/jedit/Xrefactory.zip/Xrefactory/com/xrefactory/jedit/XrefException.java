package com.xrefactory.jedit;

class XrefException extends Exception {
	XrefException(String message) {
		super(message);
	}

}
