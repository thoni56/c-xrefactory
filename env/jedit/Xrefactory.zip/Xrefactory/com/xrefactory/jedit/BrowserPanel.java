package com.xrefactory.jedit;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.event.*;
import javax.swing.event.*;
import org.gjt.sp.jedit.*;
import org.gjt.sp.jedit.gui.*;


public class BrowserPanel extends JPanel {

	DispatchData		data;
	BrowserTopPanel		top;
	static int			idCounter = 0;
	int					id;
	
	public Component getComponent() {return(this);}
	public String getName() {return(s.dockableBrowserWindowName);}

/*
	class ButtonPop extends JButton implements ActionListener {
		ButtonPop() {super("Pop"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);
			XrefCharBuffer receipt = ndata.xTask.callProcessSingleOpt("-olcxpop", ndata);
			Dispatch.dispatch(receipt, ndata);
			if (! ndata.panic) top.updateData();
		}
	}
	class ButtonRePush extends JButton implements ActionListener {
		ButtonRePush() {super("Re-push"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);
			XrefCharBuffer receipt = ndata.xTask.callProcessSingleOpt("-olcxrepush", ndata);
			Dispatch.dispatch(receipt, ndata);		
			if (! ndata.panic) top.updateData();
			s.displayProjectInformation();
		}
	}
	class ButtonEnter extends JButton implements ActionListener {
		ButtonEnter() {super("Enter"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);				
			JDialog parent = s.getParentDialog(this);
			if (parent!=null) {
				new PushSymbolDialog(parent, ndata);
			} else {
				JFrame parentf = s.getParentFrame(this);
				new PushSymbolDialog(parentf, ndata);
			}
			s.displayProjectInformation();
		}
	}
	class ButtonPush extends JButton implements ActionListener {
		ButtonPush() {super("Push"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);
			new Push(new String[]{"-olcxpush"}, ndata);
			s.displayProjectInformation();
		}
	}

	class ButtonCreateTagFile extends JButton implements ActionListener {
		ButtonCreateTagFile() {super("Create"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);
			XrefTaskForTagFile.runXrefOnTagFile("-create", "Creating Tags.",true, ndata);
		}
	}

	class ButtonUpdateTagFile extends JButton implements ActionListener {
		ButtonUpdateTagFile() {super("Update"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			String updateOption;
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			updateOption = "-fastupdate";
			DispatchData ndata = new DispatchData(data, this);
			XrefTaskForTagFile.runXrefOnTagFile(updateOption, "Updating Tags.",true, ndata);
		}
	}

	class ButtonFullUpdateTagFile extends JButton implements ActionListener {
		ButtonFullUpdateTagFile() {super("Full Update"); addActionListener(this);}
		public void actionPerformed( ActionEvent e) {
			s.setGlobalValues(s.getParentView(data.callerComponent),true);
			DispatchData ndata = new DispatchData(data, this);
			XrefTaskForTagFile.runXrefOnTagFile("-update", "Updating Tags.",true, ndata);
		}
	}
*/

	void init(DispatchData data) {
		int i,y,split;

		this.data = data;

		y= -1;

/*
		JButton buttons[] = {
			new ButtonPush(),
			new ButtonEnter(),
			new ButtonPop(),
			new ButtonRePush(),
		};
		JButton buttons2[] = {
			new ButtonCreateTagFile(),
			new ButtonUpdateTagFile(),
			new ButtonFullUpdateTagFile(),
		};
*/

		// TODO vertical split if docked left or right
		s.xbrowser = top = new BrowserTopPanel(data, JSplitPane.HORIZONTAL_SPLIT);
		setLayout(new GridBagLayout());

		y++;
		s.addGbcComponent(this, 0,y, 7,1, 1000,1000, 
						  GridBagConstraints.BOTH,
						  top);
/*
		y++;
		s.addGbcComponent(this, 0, y, 1, 1, 1, 1, 
						  GridBagConstraints.VERTICAL, 
						  new JSeparator(SwingConstants.VERTICAL));
		s.addGbcComponent(this, 1,y, 1,1, 100,1, 
						  GridBagConstraints.HORIZONTAL,
						  new JPanel());
		s.addExtraButtonLine(this, 2,y, 1,1, 100,1, buttons, false);
		s.addGbcComponent   (this, 3,y, 1,1, 100,1, 
							 GridBagConstraints.HORIZONTAL,
							 new JLabel("Tags:", SwingConstants.RIGHT));
		s.addExtraButtonLine(this, 4,y, 1,1, 100,1, buttons2, false);
		s.addGbcComponent(this, 5,y, 1,1, 100,1, 
						  GridBagConstraints.HORIZONTAL,
						  new JPanel());
		s.addGbcComponent(this, 6, y, 1, 1, 1, 1, 
						  GridBagConstraints.VERTICAL, 
						  new JSeparator(SwingConstants.VERTICAL));
		y++;
		s.addGbcComponent(this, 0, y, 7, 1, 1, 1, 
						  GridBagConstraints.HORIZONTAL, 
						  new JSeparator());
*/
		// this is to make initialisations
		top.needToUpdate();
	}


	void initNoBrowser() {
		int i,y;

		y= -1;
		JButton buttons[] = {
			new JButton("Close"),
		};

		y++;
		s.addGbcComponent(this, 0,y, 1,1, 1,1, 
						  GridBagConstraints.BOTH,
						  new JOptionPane("Only one browser per view can be opened", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new JPanel[] {new JPanel()}));
		y++;
		s.addGbcComponent(this, 0,y, 1,1, 1,1, 
						  GridBagConstraints.BOTH,
						  new JPanel());
		y++;
		s.addExtraButtonLine(this, 0,y, 1,1, 1,1, buttons, true);
	}


	public BrowserPanel(DispatchData data) {
		super();
		init(data);
	}

	public BrowserPanel(View view, String position) throws Exception {
		super();
		s.setGlobalValuesNoActiveProject(view);
		if (false && s.browserIsDisplayed(view)) {
			initNoBrowser();
		} else {
			this.id = idCounter++;
			DispatchData ndata = new DispatchData(s.xbTask, view);
			ndata.viewId = id;
			init(ndata);
		}
	}

}

