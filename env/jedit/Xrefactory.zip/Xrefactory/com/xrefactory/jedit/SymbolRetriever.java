package com.xrefactory.jedit;

import javax.swing.*;
import org.gjt.sp.jedit.*;
import org.gjt.sp.jedit.gui.*;
import java.awt.*;
import java.awt.event.*;

public class SymbolRetriever extends JPanel implements ActionListener {

	static int							currentId = 0;
	
    public JComboBox	   				string;
    public JCheckBox    				scanJars;
	public static XrefStringArray		history = new XrefStringArray();
    XrefSelectableLinesTextPanel        text;
  	View								view;
	int									id = 0;
	
    public Component getComponent() {return(this);}
    public String getName() {return(s.dockableRetrieverWindowName);}

    public void setResult(XrefCharBuffer text, DispatchData data) {
        this.text.data = data;
        this.text.setText(text.toString());
        this.text.setCaretPosition(0);
        this.text.renewSelection();	
	}
	
    public void setResult(XrefStringArray res, DispatchData data) {
        XrefCharBuffer text = new XrefCharBuffer();
        for(int i=0; i<res.optionsi; i++) {
            if (i!=0) text.append("\n");
            text.append(res.options[i]);
        }
		setResult(text, data);
    }

	public void actionPerformed( ActionEvent e) {
		actionContinue();
	}			

    void actionContinue() {
        s.setGlobalValues(view,true);
        String[] options;
        String string = (String) this.string.getSelectedItem();
		if (!history.getLast().equals(string)) {
			this.string.addItem(string);
			history.add(string);
		}
        if (! string.equals("")) {
            DispatchData ndata = new DispatchData(s.xbTask, view);
			ndata.viewId = id;
            if (scanJars.isSelected()) {
                options = new String[] {"-olcxtagsearch=" + string};
            } else {
                options = new String[] {"-olcxtagsearch=" + string, "-searchdef"};
            }
            XrefCharBuffer receipt = ndata.xTask.callProcessOnFile(options, ndata);
            Dispatch.dispatch(receipt, ndata);
            if (ndata.symbolList!=null && ! ndata.panic) {
                setResult(ndata.symbolList, ndata);
            }
			text.data = ndata;
        }
    }

    public SymbolRetriever(View view, String position) {
        super();
		this.view = view;
		this.id = currentId ++;

        int y = -1;
        setLayout(new GridBagLayout());
        text = new XrefSelectableLinesTextPanel("-olcxtaggoto");
        string = new JComboBox(history.toStringArray(false));
		string.setEditable(true);
        string.addActionListener(this);
        scanJars = new JCheckBox("Scan jars", false);
		JScrollPane textScrollPane = new JScrollPane(text);
		textScrollPane.setPreferredSize(new Dimension(400,300));

        y++;
        s.addGbcComponent(this, 0, y, 6, 1, 1000, 1000, 
                          GridBagConstraints.BOTH, 
                          textScrollPane);
        y++;
        s.addGbcComponent(this, 0, y, 1, 1, 1, 1, 
                          GridBagConstraints.VERTICAL, 
                          new JSeparator(SwingConstants.VERTICAL));
        s.addGbcComponent(this, 1,y, 1,1, 1,1, 
                          GridBagConstraints.HORIZONTAL,
                          new JLabel("Search symbols containing string(s):"));
        s.addGbcComponent(this, 2,y, 1,1, 1000,1, 
                          GridBagConstraints.HORIZONTAL,
                          string);
        s.addGbcComponent(this, 3,y, 1,1, 1,1, 
                          GridBagConstraints.HORIZONTAL,
                          new JPanel());
        s.addGbcComponent(this, 4,y, 1,1, 1,1, 
                          GridBagConstraints.HORIZONTAL,
                          scanJars);
        s.addGbcComponent(this, 5, y, 1, 1, 1, 1, 
                          GridBagConstraints.VERTICAL, 
                          new JSeparator(SwingConstants.VERTICAL));

        y++;
        s.addGbcComponent(this, 0, y, 6, 1, 1, 1, 
                          GridBagConstraints.HORIZONTAL, 
                          new JSeparator());
                
    }
} 
