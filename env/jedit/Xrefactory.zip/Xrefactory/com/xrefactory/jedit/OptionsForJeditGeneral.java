package com.xrefactory.jedit;

import java.io.*;
import javax.swing.*;
import org.gjt.sp.jedit.*;
import com.xrefactory.jedit.Options.*;
import com.xrefactory.jedit.OptionsForProjectsDialog.*;
import java.awt.*;
import java.awt.event.*;

public class OptionsForJeditGeneral extends AbstractOptionPane {

	static OptionsForJeditGeneral lastShowedOptions = null;

	JCheckBox completeFullyQualifiedNames;
	JCheckBox completionAccessCheck;
	JCheckBox completionLinkageCheck;
	JCheckBox fullAutoUpdate;
	JCheckBox updateBeforeRefactorings;
	JCheckBox updateBeforePush;
	JCheckBox saveFilesBeforeRefactorings;
	JCheckBox saveFilesAfterRefactorings;
	JCheckBox saveFilesAskForConfirmation;
	JCheckBox referencePushingsKeepBrowserFilter;
	JCheckBox askBeforeBrowsingJavadoc;
	JCheckBox fileNamesCaseUnSensitive;

	JComboBox maxCompletions;
	JComboBox completionDialogMaxWidth;
	JComboBox completionDialogMaxHeight;
	JComboBox activeProject;
	JTextField configurationFile;

	Options[] projects;

	Option fileNamesCaseUnsensitiveOpt = new Option(Options.optFilesCaseUnSensitive);

	class ConfigurationFileListener implements FocusListener {
		public void focusGained(FocusEvent e) {}
		public void focusLost(FocusEvent e) {
			createActiveProjectList();
		}
	}

	void createActiveProjectList() {
		try {
			OptionParser parser = new OptionParser(new File(s.configurationFile));
			projects = parser.parseFile();
			activeProject = new JComboBox(Options.getProjectNames(
				projects, s.projectAutoDetectionName));
			activeProject.setSelectedItem(Opt.activeProject());
		} catch (Exception e) {
			projects = new Options[0];
			activeProject = new JComboBox();
		}
	}

	void activeProjectListRefresh(ComboBoxModel model) {
		int n = model.getSize();
		String[] projects = new String[n];
		projects[0] = s.projectAutoDetectionName;
		for(int i=1; i<n; i++) projects[i] = (String)model.getElementAt(i);
		activeProject.setModel(new DefaultComboBoxModel(projects));
	}

	protected void _init() {
		s.setGlobalValues(s.getParentView(this), false);
		lastShowedOptions = this;

		configurationFile = new JTextField(s.configurationFile);
		//& configurationFile.addFocusListener(new ConfigurationFileListener());
		addComponent("Projects Configuration File: ", configurationFile);

		createActiveProjectList();
		addComponent("The Active Project: ", activeProject);
		addComponent(new JPanel());




		completeFullyQualifiedNames = new JCheckBox(
			"Completion completes fully qualified names from jar archives",
			Opt.completeFullyQualifiedNames());
		addComponent(completeFullyQualifiedNames);

		completionAccessCheck = new JCheckBox(
			"Completion checks accessibility (public/private/protected)",
			Opt.completionAccessCheck());
		addComponent(completionAccessCheck);

		completionLinkageCheck = new JCheckBox(
			"Completion reports only static symbols in static context.",
			Opt.completionLinkageCheck());
		addComponent(completionLinkageCheck);

		maxCompletions = new JComboBox(
			new String[]{"100","200","300","500","1000","2000","3000","5000", "10000"}
			);
		maxCompletions.setEditable(true);
		maxCompletions.setSelectedItem(""+Opt.maxCompletions());
		addComponent("Maximal number of reported completions: ", maxCompletions);

		completionDialogMaxWidth = new JComboBox(
			new String[]{"200","400","600","800","1000","1200","1400","1600"}
			);
		completionDialogMaxWidth.setEditable(true);
		completionDialogMaxWidth.setSelectedItem(""+Opt.completionDialogMaxWidth());
		addComponent("Completion window maximal width: ", completionDialogMaxWidth);

		completionDialogMaxHeight = new JComboBox(
			new String[]{"100","200","300","400","500","600","700","800","900"}
			);
		completionDialogMaxHeight.setEditable(true);
		completionDialogMaxHeight.setSelectedItem(""+Opt.completionDialogMaxHeight());
		addComponent("Completion window maximal height: ", completionDialogMaxHeight);


		//&addComponent(new JPanel());





		referencePushingsKeepBrowserFilter = new JCheckBox(
			"Keep reference filter over pushing (in browser)",
			Opt.referencePushingsKeepBrowserFilter());
		addComponent(referencePushingsKeepBrowserFilter);

		askBeforeBrowsingJavadoc = new JCheckBox(
			"Ask for confirmation before browsing URL",
			Opt.askBeforeBrowsingJavadoc());
		addComponent(askBeforeBrowsingJavadoc);

		updateBeforePush = new JCheckBox(
			"Update tags before pushing references",
			Opt.updateBeforePush());
		addComponent(updateBeforePush);

		fullAutoUpdate = new JCheckBox(
			"Updating of tags provides full update (with dependencies checks)",
			Opt.fullAutoUpdate());
		addComponent(fullAutoUpdate);

		/*&   // too dangerous
		  fileNamesCaseUnSensitive = new JCheckBox(
		  "File names are considered case unsensitive",
		  (projects.length>0 && projects[0].contains(fileNamesCaseUnsensitiveOpt)));
		  addComponent(fileNamesCaseUnSensitive);
		  &*/

		//&addComponent(new JPanel());





		updateBeforeRefactorings = new JCheckBox(
			"Update tags before refactoring",
			Opt.updateBeforeRefactorings());
		addComponent(updateBeforeRefactorings);

		saveFilesBeforeRefactorings = new JCheckBox(
			"Save all modified buffers before refactoring",
			Opt.saveFilesBeforeRefactorings());
		addComponent(saveFilesBeforeRefactorings);

		saveFilesAfterRefactorings = new JCheckBox(
			"Save all modified buffers after refactoring",
			Opt.saveFilesAfterRefactorings());
		addComponent(saveFilesAfterRefactorings);

		saveFilesAskForConfirmation = new JCheckBox(
			"Automatic saving of buffers asks for confirmation",
			Opt.saveFilesAskForConfirmation());
		addComponent(saveFilesAskForConfirmation);

	}


	protected void _save() {
		//&panel.saveProjectSettings();
		if (! s.configurationFile.equals(configurationFile.getText())) {
			jEdit.setProperty(s.configurationFileOption, configurationFile.getText());
			JOptionPane.showMessageDialog(s.view, 
										  "You must restart jEdit in order to use new Xrefactory configuration file.", 
										  "Xrefactory Message", JOptionPane.INFORMATION_MESSAGE);
		}

		Opt.setActiveProject((String)activeProject.getSelectedItem());
		Opt.setCompleteFullyQualifiedNames(completeFullyQualifiedNames.isSelected());
		Opt.setCompletionAccessCheck(completionAccessCheck.isSelected());
		Opt.setCompletionLinkageCheck(completionLinkageCheck.isSelected());
		try {
			Opt.setMaxCompletions(Integer.parseInt(
				(String)maxCompletions.getSelectedItem()));
		} catch (Exception e) {}
		try {
			Opt.setCompletionDialogMaxWidth(Integer.parseInt(
				(String)completionDialogMaxWidth.getSelectedItem()));
		} catch (Exception e) {}
		try {
			Opt.setCompletionDialogMaxHeight(Integer.parseInt(
				(String)completionDialogMaxHeight.getSelectedItem()));
		} catch (Exception e) {}
		Opt.fullAutoUpdate(fullAutoUpdate.isSelected());
		Opt.setAskBeforeBrowsingJavadoc(askBeforeBrowsingJavadoc.isSelected());
		Opt.setUpdateBeforeRefactorings(updateBeforeRefactorings.isSelected());
		Opt.setUpdateBeforePush(updateBeforePush.isSelected());
		Opt.setSaveFilesBeforeRefactorings(saveFilesBeforeRefactorings.isSelected());
		Opt.setSaveFilesAfterRefactorings(saveFilesAfterRefactorings.isSelected());
		Opt.setSaveFilesAskForConfirmation(saveFilesAskForConfirmation.isSelected());
		Opt.setReferencePushingsKeepBrowserFilter(referencePushingsKeepBrowserFilter.isSelected());


		// modifying .xrefrc file
		if (projects.length>0) {
			boolean saveRequired = false;
			/*&
			  if (fileNamesCaseUnSensitive.isSelected()) {
			  if (! projects[0].contains(fileNamesCaseUnsensitiveOpt)) {
			  projects[0].add(fileNamesCaseUnsensitiveOpt);
			  saveRequired = true;
			  }
			  } else {
			  if (projects[0].contains(fileNamesCaseUnsensitiveOpt)) {
			  projects[0].delete(fileNamesCaseUnsensitiveOpt);
			  saveRequired = true;
			  }
			  }
			  &*/
		}

	}

	public OptionsForJeditGeneral() {
		super("xrefactory-general");
	}
}



