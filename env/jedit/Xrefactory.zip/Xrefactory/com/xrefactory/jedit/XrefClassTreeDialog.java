package com.xrefactory.jedit;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import javax.swing.border.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.event.*;

class XrefClassTreeDialog extends JDialog {

	static XrefClassTreeDialog	current=null;

	XrefClassTreeDialog(Frame parent, String list, DispatchData data, int lineOffset, int baseLine) {
		super(parent);
		if (current!=null && current.isVisible()) current.setVisible(false);
		current = this;
		Dimension size;
		Point location = s.recommendedLocation(s.getTextArea());
		XrefSelectableLinesTextPanel pp = new XrefSelectableLinesTextPanel(list, data, "-olcxctinspectdef", lineOffset, baseLine);
		JScrollPane panel = new JScrollPane(pp);
		if (pp.countPreferredSize().getHeight()>=300) {
			panel.setPreferredSize(new Dimension(400,300));
		} else {
			double ny = location.getY() - pp.getCaretLineShiftOffset() + 5;
			if (ny > 0) {
				location.setLocation(location.getX(), ny);
			}
		}
		setContentPane(panel);
		//if (s.javaVersion.compareTo("1.4.0") >= 0) setUndecorated(true);
		pack();
		setLocation(location);
		s.moveOnScreen(this);
		setVisible(true);
		pp.renewSelection();
	}
}



