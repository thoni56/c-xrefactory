// No package here, will be copied to top level
package com.xrefactory.jedit;

import org.gjt.sp.jedit.*;
import org.gjt.sp.jedit.textarea.*;

public class Xrefactory {

}
