package com.xrefactory.jedit;

class XrefAbortException  extends XrefException {

	XrefAbortException() {
		super("abort");
	}

}
